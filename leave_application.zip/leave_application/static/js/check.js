var input_num = document.getElementById('proceed')
var apply = document.getElementById('apply')

apply.style.display = 'none'
// input_num.style.border = 'none'

input_num.addEventListener("change", function(){
    if(input_num.value == 'sick' || input_num.value == 'vacation' || input_num.value == 'annual'){
        apply.style.display = 'block'
    }
})