from django.urls import path
from . import views

app_name = 'basic_app'

urlpatterns = [
        path('registration/', views.registration, name='registration'),
        path('check_reason/', views.check_reason, name='check_reason'),
        path('application_form/', views.application_form, name='application_form'),
        path('user_login/', views.user_login, name='user_login')
]