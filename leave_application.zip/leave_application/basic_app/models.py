from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Application(models.Model):
    first_name = models.CharField(max_length=264)
    last_name = models.CharField(max_length=264)
    email_address = models.EmailField()
    phone_number = models.CharField(max_length=264)
    address = models.CharField(max_length=264)
    reason_for_leave = models.CharField(max_length=264)
    start_date = models.DateField()
    end_date = models.DateField()

    def __str__(self):
        return self.last_name + " " + self.first_name

class UserProfileInfo(models.Model):

    #CREATE ONE TO ONE RELATIONSHIP WITH USER

    user = models.OneToOneField(User, on_delete=callable)

    #ADD ADDITIONAL 

    portfolio_site = models.URLField(blank=True) 
    profile_pic = models.ImageField(upload_to='profile_pics', blank=True)

    def __str__(self):
        return self.user.username