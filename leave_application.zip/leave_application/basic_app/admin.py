from django.contrib import admin
from basic_app.models import Application, UserProfileInfo

# Register your models here.

admin.site.register(Application)
admin.site.register(UserProfileInfo)
